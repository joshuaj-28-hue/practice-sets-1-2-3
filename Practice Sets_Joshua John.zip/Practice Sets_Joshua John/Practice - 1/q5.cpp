#include<iostream>
using namespace std;
int main(){
int n;
cout<<"enter n:"<<endl;
cin>>n;
if (n>0)
{
    cout<<"the number is postive";

}
else if (n<0)
{
    cout<<"the number is negative";
}
else
{
    cout<<"the number entered is 0";

}

return 0;


}