#include<iostream>
using namespace std;
int main(){
int num;
cout<<"enter the number to check even or odd"<<endl;
cin>>num;
if (num%2==0)
{
    cout<<"the number is even"<<endl;
}
else{
    cout<<"it is odd"<<endl;
}
return 0;
}