#include<iostream>
using namespace std;
int main(){
int year;
cout<<"enter the year:";
cin>>year;
if (year%4==0)
{
    cout<<"the year is a LEAP year";
}
else{
    cout<<"its not a leap yeatr";
}


return 0;


}