#include<iostream>
using namespace std;
int main(){
float SI;
int p,r,t;
cout<<"enter the values of p,r,t"<<endl;
cin>>p>>r>>t;
SI=(p*r*t)/100;
cout<<"the si for the given time and rate of intrest is:"<<SI;

return 0;



}