#include<iostream>
using namespace std;
int main(){
for (int i = 1; i <101; i++)
{
    cout<<"the numbers from 1-100:"<<i<<endl;
}



return 0;

}
