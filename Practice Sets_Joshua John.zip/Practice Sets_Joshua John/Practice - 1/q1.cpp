#include<iostream>
using namespace std;

int main(){

int age;
string name;
cout<<"type ur name:"<<endl;
cin>>name;
cout<<"type ur age:"<<endl;
cin>>age;
cout<<"name is: " <<name<< " age is:"<<age<<endl;


    return 0;
}