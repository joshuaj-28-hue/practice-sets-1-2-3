#include<iostream>
#include<string.h>
using namespace std;
class details{
    public:
    int rollno;
    float marks;
    string name;
};


int main(){
details d1;
d1.name="alokk";
d1.marks=26;
d1.rollno=12;
cout<<"name:"<<d1.name'
}