#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"enter n:";
    cin>>n;
    do
    {
        
    } while (n > 0); // Replace 'condition' with a valid boolean expression
    
}