#include<iostream>
using namespace std;
int main(){
   
int n;
cout<<"enter n :"<<endl;
cin>>n;
do{
    int digit;
    digit=n%10;
    cout<<digit;
    n=n/10;

}
while (n>0);
return 0;
}