#include <iostream>
using namespace std;

class BankAccount {
private:
    int balance;
    string holder;

public:
    BankAccount(string n, int b) {
        balance = b;
        holder = n;
    }

    void deposit(int amount) {
        balance += amount;
        cout << "Balance after deposit: " << balance << endl;
    }

    void withdraw(int amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Balance after withdrawal: " << balance << endl;
        } else {
            cout << "Cannot withdraw." << endl;
        }
    }

    void display() {
        cout << "Account holder: " << holder << endl;
        cout << "Balance: " << balance << endl;
    }
};

int main() {
    BankAccount acc("Priya", 4000);
    acc.deposit(800);
    acc.display();
    acc.withdraw(600);
    acc.display();
    // acc.balance = 1000; // Error: balance is private, encapsulation prevents invalid changes
    return 0;
}
