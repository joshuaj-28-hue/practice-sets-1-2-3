#include <iostream>
using namespace std;

class Shape {
public:
    virtual void area() = 0;
};

class Circle : public Shape {
private:
    float r;

public:
    Circle(float radius) {
        r = radius;
    }

    void area() override {
        cout << "Area of circle: " << 3.14 * r * r << endl;
    }
};

class Square : public Shape {
private:
    int a;

public:
    Square(int side) {
        a = side;
    }

    void area() override {
        cout << "Area of square: " << a * a << endl;
    }
};

int main() {
    Circle c(7);
    Square s(5);

    Shape *ptr;

    ptr = &c;
    ptr->area();

    ptr = &s;
    ptr->area();

    return 0;
}