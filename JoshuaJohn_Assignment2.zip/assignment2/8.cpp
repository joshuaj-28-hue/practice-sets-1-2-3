#include <iostream>
using namespace std;

class shape {
public:
    void area(int side) {
        cout << "Area of square: " << side * side << endl;
    }
    void area(int length, int width) {
        cout << "Area of rectangle: " << length * width << endl;
    }
    virtual void display() {
        cout << "This is a base shape" << endl;
    }
};

class derived : public shape {
public:
    void display() override {
        cout << "This is a derived shape" << endl;
    }
};

int main() {
    shape sh;
    derived dr;
    sh.area(6);         // Calls area(int)
    sh.area(6, 12);     // Calls area(int, int)
    shape *ptr;
    ptr = &dr;
    ptr->display();     // Calls derived's display (runtime polymorphism)
    return 0;
}
