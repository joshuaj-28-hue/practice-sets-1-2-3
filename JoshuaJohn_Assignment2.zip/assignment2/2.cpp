#include <iostream>
#include <string>
using namespace std;

class dictionary {
private:
    string keys[50];
    string vals[50];
    int count = 0;

public:
    void addpair(string newk, string newv) {
        for (int i = 0; i < count; i++) {
            if (keys[i] == newk) {
                cout << "duplicate keys soo update the value of the key" << endl;
                vals[i] = newv;
            }
        }
        keys[count] = newk;
        vals[count] = newv;
        count++;
    }

    void search(string findk) {
        for (int i = 0; i < count; i++) {
            if (keys[i] == findk) {
                cout << "key is found at:" << i << endl;
                cout << "key:" << keys[i] << " " << "vlaues is :" << vals[i] << endl;
                return;
            }
        }
        cout << "key not found" << endl;
    }

    void display() {
        for (int i = 0; i < count; i++) {
            cout << "key is :" << keys[i] << " " << "values is :" << vals[i] << endl;
        }
    }
};

int main() {
    dictionary d;

    d.addpair("name", "somenamee");
    d.addpair("age", "30");
    d.addpair("school", "someschool");

    d.search("age");
    d.display();

    return 0;
}
