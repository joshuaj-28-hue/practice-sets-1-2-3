#include <iostream>
using namespace std;

class person {
protected:
    string pname;
    int page;

public:
    void set_person(string n, int a) {
        pname = n;
        page = a;
    }
    void show_person() {
        cout << "name: " << pname << endl;
        cout << "age: " << page << endl;
    }
};

class employee : public person {
protected:
    int eid;
    int esalary;

public:
    void set_employee(int id, int sal) {
        eid = id;
        esalary = sal;
    }
    void show_employee() {
        cout << "id: " << eid << endl;
        cout << "salary is: " << esalary << endl;
    }
};

class manager : public employee {
protected:
    string dept;

public:
    void set_dept(string d) {
        dept = d;
    }
    void show_manager() {
        cout << "department is :" << dept << endl;
    }

    void show_all() {
        show_person();
        show_employee();
        show_manager();
    }
};

int main() {
    manager m;
    m.set_person("somename", 34);
    m.set_employee(5454, 4000);
    m.set_dept("math");
    m.show_all();
    return 0;
}
