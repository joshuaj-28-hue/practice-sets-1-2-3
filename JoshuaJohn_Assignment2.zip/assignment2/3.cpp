#include <iostream>
using namespace std;

class shape {
protected:
    int l;
    int b;
};

class rectangle : public shape {
public:
    rectangle(int x, int y) {
        l = x;
        b = y;
    }

    void area() {
        int a = l * b;
        cout << "the area is :" << a;
    }

    void perimeter() {
        int p = 2 * (l + b);
        cout << "the perimeter is :" << p;
    }
};

int main() {
    rectangle r1(6, 10);
    r1.area();
    r1.perimeter();

    return 0;
}
