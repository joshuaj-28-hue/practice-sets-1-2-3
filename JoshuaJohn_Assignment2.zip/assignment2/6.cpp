#include <iostream>
using namespace std;

class sports;

class student {
protected:
    string pname;
    int grade;

public:
    student(string n, int g) {
        pname = n;
        grade = g;
    }

    friend void show_details(student st, sports sp);
};

class sports {
protected:
    int points;

public:
    sports(int p) {
        points = p;
    }

    friend void show_details(student st, sports sp);
};

void show_details(student st, sports sp) {
    cout << "Name, marks, and score: " << st.pname << " " << st.grade << " " << sp.points;
}

int main() {
    student st1("Rahul", 78);
    sports sp1(110);
    show_details(st1, sp1);
    return 0;
}
