#include <iostream>
using namespace std;

class list {
private:
    int *data;
    int len;
    int limit;

public:
    list(int lmt = 5) {
        limit = lmt;
        len = 0;
        data = new int[limit];
    }

    void add(int val) {
        if (len == limit) {
            cout << "array is full";
        } else {
            data[len] = val;
            len++;
        }
    }

    void remove(int val) {
        int pos = -1;
        for (int i = 0; i < len; i++) {
            if (data[i] == val) {
                pos = i;
                break;
            }
        }

        if (pos == -1) {
            cout << "element not found";
            return;
        }

        for (int i = pos; i < len - 1; i++) {
            data[i] = data[i + 1];
        }

        len--;
    }

    void get_size() {
        cout << "the size is :" << len;
    }

    void display() {
        for (int i = 0; i < len; i++) {
            cout << data[i] << "\t";
        }
    }

    int &operator[](int index) {
        if (index < 0 || index >= len) {
            cout << "invalid index";
        } else {
            cout << "the element at the index is :" << data[index] << endl;
        }
    }
};

int main() {
    list l1;

    l1.add(1);
    l1.add(2);
    l1.add(3);
    l1.add(4);
    l1.add(5);

    l1.remove(3);

    l1.display();

    l1[0];

    return 0;
}
