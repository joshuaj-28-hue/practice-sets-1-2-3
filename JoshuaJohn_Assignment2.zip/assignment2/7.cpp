#include <iostream>
using namespace std;

class sort_arr {
private:
    int n;
    int data[50];

public:
    void input() {
        cout << "Enter array size:" << endl;
        cin >> n;
        cout << "Enter the numbers:" << endl;
        for (int idx = 0; idx < n; idx++) {
            cin >> data[idx];
        }
    }

    void display() {
        for (int idx = 0; idx < n; idx++) {
            cout << data[idx] << endl;
        }
    }

    void bubble_sort() {
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (data[j + 1] < data[j]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
        cout << "Array after Bubble Sort:" << endl;
        display();
    }

    void insertion_sort() {
        for (int i = 0; i < n; i++) {
            int key = data[i];
            int j = i - 1;
            while (j >= 0 && data[j] > key) {
                data[j + 1] = data[j];
                j = j - 1;
            }
            data[j + 1] = key;
        }
        cout << "Array after Insertion Sort:" << endl;
        display();
    }

    void selection_sort() {
        for (int i = 0; i < n - 1; i++) {
            int min_pos = i;
            for (int j = i + 1; j < n; j++) {
                if (data[j] < data[min_pos]) {
                    min_pos = j;
                }
            }
            int temp = data[i];
            data[i] = data[min_pos];
            data[min_pos] = temp;
        }
        cout << "Array after Selection Sort:" << endl;
        display();
    }
};

int main() {
    sort_arr sa;
    sa.input();
    sa.bubble_sort();
    sa.insertion_sort();
    sa.selection_sort();
    return 0;
}